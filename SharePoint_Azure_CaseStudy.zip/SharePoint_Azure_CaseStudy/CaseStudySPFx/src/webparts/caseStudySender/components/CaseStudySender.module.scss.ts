/* tslint:disable */
require("./CaseStudySender.module.css");
const styles = {
  caseStudySender: 'caseStudySender_4cce4f00',
  teams: 'teams_4cce4f00',
  welcome: 'welcome_4cce4f00',
  welcomeImage: 'welcomeImage_4cce4f00',
  links: 'links_4cce4f00'
};

export default styles;
/* tslint:enable */