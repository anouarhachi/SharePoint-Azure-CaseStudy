declare const styles: {
    caseStudySender: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=CaseStudySender.module.scss.d.ts.map